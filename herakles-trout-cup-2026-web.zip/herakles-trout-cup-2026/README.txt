HERAKLES TROUT CUP 2026 - webová verze propozic

Soubor index.html je kompletní samostatná stránka a nevyžaduje žádné další soubory.
Je připravený pro bezplatný hosting na GitHub Pages, Cloudflare Pages nebo Netlify.

Doporučený postup pro GitHub Pages:
1. Vytvořit nový veřejný repozitář, např. herakles-trout-cup-2026.
2. Nahrát index.html do kořene repozitáře.
3. Settings > Pages > Deploy from a branch > main / root.
4. Po zveřejnění vznikne veřejná URL ve tvaru https://UZIVATEL.github.io/herakles-trout-cup-2026/
